/*! licenses: /vendor.LICENSE.txt */
import{al as n,am as o,an as s,ao as u,hY as i}from"./main-8gICal5p.js";import{a as r,d as p}from"./application-SkxnT7ua.js";const y=n(e=>o({queryKey:["application","leak",e],queryFn:()=>r(e)}));function m(){const e=s();return u({mutationFn:a=>p(a),onSuccess:(a,t)=>{i(t,e)}})}export{m as a,y as u};
//# sourceMappingURL=applications-DDkS0UuY.js.map
