/*! licenses: /vendor.LICENSE.txt */
import{j as a,S as s,ay as t,M as i}from"./echoes-Bhfm30Zr.js";import{a as r}from"./vendor-CosJKDqA.js";const d=r.forwardRef((e,o)=>a.jsx(s,{...e,IconLeft:t,ref:o,variety:"highlight",children:a.jsx(i,{id:"contains_ai_code"})}));d.displayName="ContainsAICodeBadge";export{d as C};
//# sourceMappingURL=ContainsAICodeBadge-CqaZ1Fv3.js.map
