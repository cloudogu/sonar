/*! licenses: /vendor.LICENSE.txt */
import{bP as s,aj as t,em as o,b2 as r,ai as e,cs as p,bA as i,kJ as l,ak as m,cp as b,c7 as c,af as n,aS as S}from"./main-8gICal5p.js";import"./vendor-CosJKDqA.js";import"./echoes-Bhfm30Zr.js";import"./lodash-DZXqzBor.js";import"./highlightjs-CFvgWmRf.js";import"./datefns-GSH1D4xx.js";const w=()=>{const a=window;a.SonarRequest={request:c,get:b,getJSON:m,getText:l,omitNil:i,parseError:p,post:e,postJSON:r,postJSONBody:o,throwGlobalError:t,addGlobalSuccessMessage:s},a.t=n,a.tp=S};export{w as default};
//# sourceMappingURL=exposeLibraries-DTyOtpNM.js.map
