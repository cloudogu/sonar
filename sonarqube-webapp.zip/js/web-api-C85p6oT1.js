/*! licenses: /vendor.LICENSE.txt */
import{b3 as e}from"./main-8gICal5p.js";import{f as r,a as n}from"./web-api-Dt6iIVep.js";function t(){return e({queryKey:["web-api"],queryFn:()=>r(!1)})}const a=()=>e({queryKey:["open_api"],queryFn:n,staleTime:1/0,gcTime:1/0});export{a,t as u};
//# sourceMappingURL=web-api-C85p6oT1.js.map
