/*! licenses: /vendor.LICENSE.txt */
import{aT as n,af as i,d as r}from"./main-8gICal5p.js";import{j as t}from"./echoes-Bhfm30Zr.js";function d({className:e,qualifier:s,visibility:a}){return t.jsx(n,{content:i("visibility",a,"description",s),"data-component":"privacy-badge-container",children:t.jsx("div",{className:r("badge",e),children:i("visibility",a)})})}export{d as P};
//# sourceMappingURL=PrivacyBadgeContainer-CpQF3sZX.js.map
