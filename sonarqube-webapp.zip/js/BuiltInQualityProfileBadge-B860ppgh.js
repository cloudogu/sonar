/*! licenses: /vendor.LICENSE.txt */
import{j as i}from"./echoes-Bhfm30Zr.js";import"./vendor-CosJKDqA.js";import{dS as n,af as r,aT as o}from"./main-8gICal5p.js";function f({className:a,tooltip:e=!0}){const t=i.jsx(n,{className:a,variant:"default",children:r("quality_profiles.built_in")});return e?i.jsx(o,{content:r("quality_profiles.built_in.description"),children:t}):t}export{f as B};
//# sourceMappingURL=BuiltInQualityProfileBadge-B860ppgh.js.map
