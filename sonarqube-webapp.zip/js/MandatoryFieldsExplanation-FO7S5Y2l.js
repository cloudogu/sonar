/*! licenses: /vendor.LICENSE.txt */
import{j as e,D as r,M as t}from"./echoes-Bhfm30Zr.js";import"./vendor-CosJKDqA.js";import"./main-8gICal5p.js";import{R as s}from"./RequiredIcon-CNTXBlvD.js";function m({className:a}){return e.jsx(r,{"aria-hidden":!0,className:a,isSubtle:!0,"data-component":"mandatory-fields-explanation",children:e.jsx(t,{id:"fields_marked_with_x_required",values:{star:e.jsx(s,{className:"sw-m-0"})}})})}export{m as M};
//# sourceMappingURL=MandatoryFieldsExplanation-FO7S5Y2l.js.map
