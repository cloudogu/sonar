/*! licenses: /vendor.LICENSE.txt */
import{cp as u,jk as s,al as t,am as o}from"./main-8gICal5p.js";function n(e){return u("/api/sources/raw",e).then(s)}const a=6e4;function c(e,r){return["sources","details",e,r]}const i=t(e=>o({queryKey:c(e.key,e),queryFn:()=>n(e),staleTime:a}));export{i as u};
//# sourceMappingURL=sources-CHMmle0w.js.map
