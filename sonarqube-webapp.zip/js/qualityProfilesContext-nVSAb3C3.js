/*! licenses: /vendor.LICENSE.txt */
import{aA as n}from"./main-8gICal5p.js";import{j as s}from"./echoes-Bhfm30Zr.js";import{v as e}from"./vendor-CosJKDqA.js";function p(t){function o(i){const r=e();return s.jsx(t,{...i,...r,"data-component":"component-with-quality-profiles-props"})}return o.displayName=n(t,"withQualityProfilesContext"),o}function f(){return e()}export{f as u,p as w};
//# sourceMappingURL=qualityProfilesContext-nVSAb3C3.js.map
