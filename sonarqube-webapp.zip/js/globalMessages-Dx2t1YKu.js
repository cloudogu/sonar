/*! licenses: /vendor.LICENSE.txt */
import{B as e}from"./echoes-Bhfm30Zr.js";import{cs as s}from"./main-8gICal5p.js";function n(r){return r instanceof Response?s(r).then(o=>{e.error({description:o,duration:"short"})},()=>{}):typeof r=="string"?Promise.resolve(r).then(o=>{e.error({description:o,duration:"short"})}):Promise.resolve()}export{n as a};
//# sourceMappingURL=globalMessages-Dx2t1YKu.js.map
