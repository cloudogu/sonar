/*! licenses: /vendor.LICENSE.txt */
import{b as o,j as r}from"./echoes-Bhfm30Zr.js";function h(e){return function(t){const n=o();return r.jsx(e,{theme:n,...t})}}export{h as w};
//# sourceMappingURL=withTheme-D7A7h0UK.js.map
