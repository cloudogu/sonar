/*! licenses: /vendor.LICENSE.txt */
import{j as t,S as e,U as i,M as s}from"./echoes-Bhfm30Zr.js";function r({className:a}){return t.jsx(e,{className:a,variety:i.Neutral,"data-component":"built-in-quality-gate-badge",children:t.jsx(s,{id:"quality_gates.built_in"})})}export{r as B};
//# sourceMappingURL=BuiltInQualityGateBadge-CCPlh6ZU.js.map
