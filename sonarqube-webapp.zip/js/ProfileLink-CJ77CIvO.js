/*! licenses: /vendor.LICENSE.txt */
import{j as n}from"./echoes-Bhfm30Zr.js";import"./vendor-CosJKDqA.js";import{cj as a,k8 as e}from"./main-8gICal5p.js";function f({name:o,language:t,children:r,...i}){return n.jsx(a,{to:e(o,t),...i,"data-component":"profile-link",children:r})}export{f as P};
//# sourceMappingURL=ProfileLink-CJ77CIvO.js.map
