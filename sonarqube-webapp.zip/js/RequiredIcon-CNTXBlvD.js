/*! licenses: /vendor.LICENSE.txt */
import{c as o}from"./main-8gICal5p.js";import{j as r,t as e}from"./echoes-Bhfm30Zr.js";function c(t){return r.jsx(n,{...t,"data-component":"required-icon",children:"*"})}const n=o("span",{target:"e1se3pf80"})("color:",e("color-text-danger"),";font:",e("typography-others-label-medium"),";margin-left:",e("dimension-space-25"),";");export{c as R};
//# sourceMappingURL=RequiredIcon-CNTXBlvD.js.map
